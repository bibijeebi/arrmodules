from typing import Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateChanges")


@_attrs_define
class UpdateChanges:
    """
    Attributes:
        new (Union[List[str], None, Unset]):
        fixed (Union[List[str], None, Unset]):
    """

    new: Union[List[str], None, Unset] = UNSET
    fixed: Union[List[str], None, Unset] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        new: Union[List[str], None, Unset]
        if isinstance(self.new, Unset):
            new = UNSET
        elif isinstance(self.new, list):
            new = self.new

        else:
            new = self.new

        fixed: Union[List[str], None, Unset]
        if isinstance(self.fixed, Unset):
            fixed = UNSET
        elif isinstance(self.fixed, list):
            fixed = self.fixed

        else:
            fixed = self.fixed

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if new is not UNSET:
            field_dict["new"] = new
        if fixed is not UNSET:
            field_dict["fixed"] = fixed

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()

        def _parse_new(data: object) -> Union[List[str], None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                new_type_0 = cast(List[str], data)

                return new_type_0
            except:  # noqa: E722
                pass
            return cast(Union[List[str], None, Unset], data)

        new = _parse_new(d.pop("new", UNSET))

        def _parse_fixed(data: object) -> Union[List[str], None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                fixed_type_0 = cast(List[str], data)

                return fixed_type_0
            except:  # noqa: E722
                pass
            return cast(Union[List[str], None, Unset], data)

        fixed = _parse_fixed(d.pop("fixed", UNSET))

        update_changes = cls(
            new=new,
            fixed=fixed,
        )

        return update_changes
