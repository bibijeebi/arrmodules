from typing import Any, Dict, Type, TypeVar, Union

from attrs import define as _attrs_define

from ..models.add_movie_method import AddMovieMethod
from ..models.monitor_types import MonitorTypes
from ..types import UNSET, Unset

T = TypeVar("T", bound="AddMovieOptions")


@_attrs_define
class AddMovieOptions:
    """
    Attributes:
        ignore_episodes_with_files (Union[Unset, bool]):
        ignore_episodes_without_files (Union[Unset, bool]):
        monitor (Union[Unset, MonitorTypes]):
        search_for_movie (Union[Unset, bool]):
        add_method (Union[Unset, AddMovieMethod]):
    """

    ignore_episodes_with_files: Union[Unset, bool] = UNSET
    ignore_episodes_without_files: Union[Unset, bool] = UNSET
    monitor: Union[Unset, MonitorTypes] = UNSET
    search_for_movie: Union[Unset, bool] = UNSET
    add_method: Union[Unset, AddMovieMethod] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        ignore_episodes_with_files = self.ignore_episodes_with_files

        ignore_episodes_without_files = self.ignore_episodes_without_files

        monitor: Union[Unset, str] = UNSET
        if not isinstance(self.monitor, Unset):
            monitor = self.monitor.value

        search_for_movie = self.search_for_movie

        add_method: Union[Unset, str] = UNSET
        if not isinstance(self.add_method, Unset):
            add_method = self.add_method.value

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if ignore_episodes_with_files is not UNSET:
            field_dict["ignoreEpisodesWithFiles"] = ignore_episodes_with_files
        if ignore_episodes_without_files is not UNSET:
            field_dict["ignoreEpisodesWithoutFiles"] = ignore_episodes_without_files
        if monitor is not UNSET:
            field_dict["monitor"] = monitor
        if search_for_movie is not UNSET:
            field_dict["searchForMovie"] = search_for_movie
        if add_method is not UNSET:
            field_dict["addMethod"] = add_method

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        ignore_episodes_with_files = d.pop("ignoreEpisodesWithFiles", UNSET)

        ignore_episodes_without_files = d.pop("ignoreEpisodesWithoutFiles", UNSET)

        _monitor = d.pop("monitor", UNSET)
        monitor: Union[Unset, MonitorTypes]
        if isinstance(_monitor, Unset):
            monitor = UNSET
        else:
            monitor = MonitorTypes(_monitor)

        search_for_movie = d.pop("searchForMovie", UNSET)

        _add_method = d.pop("addMethod", UNSET)
        add_method: Union[Unset, AddMovieMethod]
        if isinstance(_add_method, Unset):
            add_method = UNSET
        else:
            add_method = AddMovieMethod(_add_method)

        add_movie_options = cls(
            ignore_episodes_with_files=ignore_episodes_with_files,
            ignore_episodes_without_files=ignore_episodes_without_files,
            monitor=monitor,
            search_for_movie=search_for_movie,
            add_method=add_method,
        )

        return add_movie_options
