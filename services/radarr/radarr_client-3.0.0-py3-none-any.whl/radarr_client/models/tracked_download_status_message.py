from typing import Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="TrackedDownloadStatusMessage")


@_attrs_define
class TrackedDownloadStatusMessage:
    """
    Attributes:
        title (Union[None, Unset, str]):
        messages (Union[List[str], None, Unset]):
    """

    title: Union[None, Unset, str] = UNSET
    messages: Union[List[str], None, Unset] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        title: Union[None, Unset, str]
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        messages: Union[List[str], None, Unset]
        if isinstance(self.messages, Unset):
            messages = UNSET
        elif isinstance(self.messages, list):
            messages = self.messages

        else:
            messages = self.messages

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if title is not UNSET:
            field_dict["title"] = title
        if messages is not UNSET:
            field_dict["messages"] = messages

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()

        def _parse_title(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_messages(data: object) -> Union[List[str], None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                messages_type_0 = cast(List[str], data)

                return messages_type_0
            except:  # noqa: E722
                pass
            return cast(Union[List[str], None, Unset], data)

        messages = _parse_messages(d.pop("messages", UNSET))

        tracked_download_status_message = cls(
            title=title,
            messages=messages,
        )

        return tracked_download_status_message
