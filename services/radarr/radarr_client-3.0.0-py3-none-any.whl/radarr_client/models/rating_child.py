from typing import Any, Dict, Type, TypeVar, Union

from attrs import define as _attrs_define

from ..models.rating_type import RatingType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RatingChild")


@_attrs_define
class RatingChild:
    """
    Attributes:
        votes (Union[Unset, int]):
        value (Union[Unset, float]):
        type (Union[Unset, RatingType]):
    """

    votes: Union[Unset, int] = UNSET
    value: Union[Unset, float] = UNSET
    type: Union[Unset, RatingType] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        votes = self.votes

        value = self.value

        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if votes is not UNSET:
            field_dict["votes"] = votes
        if value is not UNSET:
            field_dict["value"] = value
        if type is not UNSET:
            field_dict["type"] = type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        votes = d.pop("votes", UNSET)

        value = d.pop("value", UNSET)

        _type = d.pop("type", UNSET)
        type: Union[Unset, RatingType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = RatingType(_type)

        rating_child = cls(
            votes=votes,
            value=value,
            type=type,
        )

        return rating_child
