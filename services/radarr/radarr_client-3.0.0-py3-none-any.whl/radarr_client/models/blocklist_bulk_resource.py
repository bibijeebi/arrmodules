from typing import Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="BlocklistBulkResource")


@_attrs_define
class BlocklistBulkResource:
    """
    Attributes:
        ids (Union[List[int], None, Unset]):
    """

    ids: Union[List[int], None, Unset] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        ids: Union[List[int], None, Unset]
        if isinstance(self.ids, Unset):
            ids = UNSET
        elif isinstance(self.ids, list):
            ids = self.ids

        else:
            ids = self.ids

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if ids is not UNSET:
            field_dict["ids"] = ids

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()

        def _parse_ids(data: object) -> Union[List[int], None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                ids_type_0 = cast(List[int], data)

                return ids_type_0
            except:  # noqa: E722
                pass
            return cast(Union[List[int], None, Unset], data)

        ids = _parse_ids(d.pop("ids", UNSET))

        blocklist_bulk_resource = cls(
            ids=ids,
        )

        return blocklist_bulk_resource
