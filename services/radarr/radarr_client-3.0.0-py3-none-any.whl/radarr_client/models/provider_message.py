from typing import Any, Dict, Type, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..models.provider_message_type import ProviderMessageType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ProviderMessage")


@_attrs_define
class ProviderMessage:
    """
    Attributes:
        message (Union[None, Unset, str]):
        type (Union[Unset, ProviderMessageType]):
    """

    message: Union[None, Unset, str] = UNSET
    type: Union[Unset, ProviderMessageType] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        message: Union[None, Unset, str]
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if message is not UNSET:
            field_dict["message"] = message
        if type is not UNSET:
            field_dict["type"] = type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()

        def _parse_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        message = _parse_message(d.pop("message", UNSET))

        _type = d.pop("type", UNSET)
        type: Union[Unset, ProviderMessageType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = ProviderMessageType(_type)

        provider_message = cls(
            message=message,
            type=type,
        )

        return provider_message
